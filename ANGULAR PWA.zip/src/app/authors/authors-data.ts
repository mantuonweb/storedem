export const AuthorsData = [{
	"id": "1",
	"name": "Yashwant Kanetkar",
	"expertize" :"C,Java,C++"
}, {
	"id": "2",
	"name": "Dunkin Hunter",
	"expertize" :"JS,TS,Angular"
}, {
	"id": "3",
	"name": "Deborah Kurata",
	"expertize" :"JS,TS,Angular"
}];